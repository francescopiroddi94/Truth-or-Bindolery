# Copyright (C) 2025 Francesco Piroddi
#
# Questo programma è distribuito con licenza open source GPL 3.0.
# La licenza completa può essere trovata su https://www.gnu.org/licenses/gpl-3.0.html.
#
# Questo programma è distribuito senza garanzie, né implicite né esplicite, 
# comprese le garanzie di commerciabilità o idoneità per un particolare scopo.
# Vedere la licenza GPL 3.0 per i dettagli.

import random

# Funzione per generare la risposta
def rispondi():
    risposte = ["verità", "bindoleria"]
    return random.choice(risposte)

# Chiediamo all'utente di formulare una domanda
domanda = input("Fai la tua domanda: ")

# Rispondiamo con "verità" o "bindoleria"
print(rispondi())
